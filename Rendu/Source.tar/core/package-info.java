/**
 * Ce package contient le coeur du programme, c'est à dire les classes correspondant au jeu, aux joueurs, au fantômes...
 * Vous trouverez le <a href="#diagramme">diagramme de classes</a> ci-dessous.
 * <img src="core.svg" alt="Diaggramme de classe de core" id="diagramme" width ="100%">
 */
package core;