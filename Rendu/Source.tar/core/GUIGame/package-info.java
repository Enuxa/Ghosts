/**
 * Ce package contient les classes faisant fonctionner l'interface graphique.
 * Vous trouverez le <a href="#diagramme">diagramme de classes</a> ci-dessous.
 * <img src="core_GUIGame.svg" alt="Diaggramme de classe de core.GUIGame" id="diagramme" width="100%">
 */
package core.GUIGame;