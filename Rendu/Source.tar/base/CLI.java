package base;

import java.util.*;

/**
 *	Interface console
 */
public class CLI {
	private Scanner sc;
	
	/**
	 * Lit une ligne de texte saisie par l'utilisateur
	 * @param message Le message à afficher.
	 * @return Le texte saisi
	 */
	public String readText(String message) {
		System.out.print(message);
		return this.readText();
	}

	public CLI (){
		this.sc = new Scanner (System.in);
	}
	
	/**
	 * Lit une ligne de texte saisie par l'utilisateur
	 * @return Le texte saisi
	 */
	public String readText() {
		String s = this.sc.nextLine();
		if (s == null || s.equals(""))
			return null;
		return s;
	}
	
	/**
	 * Affiche un message à l'utilisateur
	 * @param message Le message à afficher
	 */
	public void printText(String message) {
		System.out.println(message);
	}

	/**
	 * Affiche un message à l'utilisateur puis attend une réponse de la part de celui-ci avant de continuer
	 * @param message1 Le message à afficher
	 * @param message2 Le message à afficher en attendant une interaction de l'utilisateur
	 */
	public void printText(String message1, String message2) {
		this.printText(message1);
		if (message2 == null)
			message2 = "Appuyez sur Entrée pour continuer...";
		System.out.print(message2);
		this.sc.nextLine();
	}

	/**
	 * Récupère une sélection parmi plusieurs chaînes
	 * @param choice Les chaînes correspondant aux différents choix
	 * @param message Le message à afficher
	 * @param min Le nombre minimum de réponses à fournir
	 * @param max Le nombre maximum de réponses à fournir
	 * @return Les réponses données
	 */
	public Collection<String> readSelection(Collection<String> choice, String message, int min, int max) {
		this.printText(message);
		return this.readSelection(choice, min, max);
	}

	/**
	 * Récupère une sélection parmi plusieurs chaînes
	 * @param c Les chaînes correspondant aux différents choix
	 * @param min Le nombre minimum de réponses à fournir
	 * @param max Le nombre maximum de réponses à fournir
	 * @return Les réponses données
	 */	
	public Collection<String> readSelection(Collection<String> c, int min, int max) {
		List<String> choice = new ArrayList<String> (c);
		for (int i = 0; i < choice.size(); i++)
			System.out.println((i+1) + " : " + choice.get(i));
		String msg = "";
		if (min == max && min != 1)
			msg = min + " réponses : ";
		if (min != max){
			if (max < min){
				int tmp = max;
				max = min;
				min = tmp;
			}
			msg = "Entre " + min + " et " + max + " réponses : ";
		}
		String ans = this.readText(msg);
		if (ans == null)
			return new ArrayList<String> ();
		String[] tab = ans.split(" ");
		Collection<String> answers = new ArrayList<String>();
		for (String s : tab){
			try{
				int n = Integer.parseInt(s);
				if (1 <= n && n <= choice.size() && answers.size() < max)
					answers.add(choice.get(n - 1));
			}catch (Exception e){}
		}
		
		if (answers.size() < min)
			return null;
		return answers;
	}

	/**
	 * Récupère un choix parmi plusieurs chaînes
	 * @param choice Les chaînes correspondant aux différents choix
	 * @param message Le message à afficher
	 * @return La réponse donnée
	 */
	public String readSelection(Collection<String> choice, String message) {
		this.printText(message);
		return this.readSelection(choice);
	}

	/**
	 * Récupère un choix parmi plusieurs chaînes
	 * @param choice Les chaînes correspondant aux différents choix
	 * @return La réponse donnée
	 */
	public String readSelection(Collection<String> choice) {
		Collection<String> c = this.readSelection(choice, 1, 1);

		if (c == null)
			return null;
		
		String a = null;
		for (String s : c)
			a = s;
		
		return a;
	}
}