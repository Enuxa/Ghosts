/**
 * Ce package contient l'extension de base du jeu.
 */
package base;